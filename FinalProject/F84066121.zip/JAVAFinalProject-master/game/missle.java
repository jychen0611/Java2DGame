package game;

public class missle //extends Tank
{

	public void add() {
		
	}
}
